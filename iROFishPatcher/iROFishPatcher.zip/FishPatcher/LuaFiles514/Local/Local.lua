g_nation_type = NATION_TYPE.USA

-- Function #0
LoadLocalFiles = function()
	require("FishPatcher\\LuaFiles514\\Local\\ServerInfo")
	require("FishPatcher\\LuaFiles514\\Local\\SkinInfo")
end
LoadLocalFiles()
