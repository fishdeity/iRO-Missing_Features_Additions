MainFrameInfo = { SkinName = "FishPatcher\\Patcher\\main_patch.bmp", w = 800, h = 500 }
ProgressBarInfo = {
	x = 20,
	y = 410,
	w = 510,
	h = 20,
	r = 250,
	g = 250,
	b = 250,
	SkinName = "FishPatcher\\Patcher\\progress_mid_full.bmp"
}
HtmlViewInfo = {
	visible = 1,
	x = 560,
	y = 40,
	w = 220,
	h = 245,
	NoticeCloseUrl = g_notice_close,
	NoticeUrl = g_notice_open
}
Ad1Button = {
	x = 20,
	y = 230,
	w = 167,
	h = 120,
	ToolTipType = ToolTipStyle.TTS_BASIC,
	ToolTip = "",
	SkinName = "FishPatcher\\Patcher\\ad_1.bmp",
	Execute = function()
	C_ExecuteButton("http://renewal.playragnarok.com/news/eventdetail.aspx?id=513", "http://renewal.playragnarok.com/news/eventdetail.aspx?id=513")
end
}
Ad2Button = {
	x = 201,
	y = 230,
	w = 167,
	h = 120,
	ToolTipType = ToolTipStyle.TTS_BASIC,
	ToolTip = "",
	SkinName = "FishPatcher\\Patcher\\ad_2.bmp",
	Execute = function()
	C_ExecuteButton("http://renewal.playragnarok.com/news/eventdetail.aspx?id=513", "http://renewal.playragnarok.com/news/eventdetail.aspx?id=513")
end
}
Ad3Button = {
	x = 383,
	y = 230,
	w = 167,
	h = 120,
	ToolTipType = ToolTipStyle.TTS_BASIC,
	ToolTip = "",
	SkinName = "FishPatcher\\Patcher\\ad_3.bmp",
	Execute = function()
	C_ExecuteButton("http://renewal.playragnarok.com/news/eventdetail.aspx?id=513", "http://renewal.playragnarok.com/news/eventdetail.aspx?id=513")
end
}
WebsiteButton = {
	x = 20,
	y = 360,
	w = 167,
	h = 40,
	ToolTipType = ToolTipStyle.TTS_BASIC,
	ToolTip = "Website",
	SkinName = "FishPatcher\\Patcher\\button_website.bmp",
	Execute = function()
	C_ExecuteButton("http://renewal.playragnarok.com/", "http://renewal.playragnarok.com/")
end
}
ForumButton = {
	x = 201,
	y = 360,
	w = 167,
	h = 40,
	ToolTipType = ToolTipStyle.TTS_BASIC,
	ToolTip = "Forum",
	SkinName = "FishPatcher\\Patcher\\button_forums.bmp",
	Execute = function()
	C_ExecuteButton("http://forums.warpportal.com/index.php?/forum/4-ragnarok-1-community/", "http://forums.warpportal.com/index.php?/forum/4-ragnarok-1-community/")
end
}
SupportButton = {
	x = 383,
	y = 360,
	w = 167,
	h = 40,
	ToolTipType = ToolTipStyle.TTS_BASIC,
	ToolTip = "Support",
	SkinName = "FishPatcher\\Patcher\\button_support.bmp",
	Execute = function()
	C_ExecuteButton("https://support.warpportal.com/Main/Default.aspx", "https://support.warpportal.com/Main/Default.aspx")
end
}
CloseButton = {
	x = 760,
	y = 13,
	w = 20,
	h = 20,
	ToolTipType = ToolTipStyle.TTS_BASIC,
	ToolTip = "Exit",
	SkinName = "FishPatcher\\Patcher\\button_close.bmp",
	Execute = function()
	C_EndDialog()
end
}
StartButton = {
	bEnable = 0,
	x = 201,
	y = 440,
	w = 118,
	h = 40,
	ToolTipType = ToolTipStyle.TTS_BASIC,
	ToolTip = "Start",
	SkinName = "FishPatcher\\Patcher\\button_play.bmp",
	Execute = function()
	if C_IsSteamOn() == 1 then
		C_ExecuteButton(g_execute_file, g_execute_stream)
	elseif C_IsPatchComplete() == 1 then
		C_ExecuteButton(g_execute_file, g_execute_arg)
	end
	C_EndDialog()
end
}
ReplayButton = {
	bEnable = 0,
	x = 334,
	y = 440,
	w = 83,
	h = 40,
	ToolTipType = ToolTipStyle.TTS_BASIC,
	ToolTip = "Replay",
	SkinName = "FishPatcher\\Patcher\\button_replay.bmp",
	Execute = function()
	if C_IsPatchComplete() == 1 then
		C_ExecuteButton(g_execute_file, g_execute_replay)
	end
	C_EndDialog()
end
}
FacebookButton = {
	x = 80,
	y = 445,
	w = 29,
	h = 29,
	ToolTipType = ToolTipStyle.TTS_BASIC,
	ToolTip = "Facebook",
	SkinName = "FishPatcher\\Patcher\\fb.bmp",
	Execute = function()
	C_ExecuteButton("https://www.facebook.com/playragnarok", "https://www.facebook.com/playragnarok")
end
}
TwitchButton = {
	x = 20,
	y = 440,
	w = 40,
	h = 40,
	ToolTipType = ToolTipStyle.TTS_BASIC,
	ToolTip = "Twitch",
	SkinName = "FishPatcher\\Patcher\\twitch.bmp",
	Execute = function()
	C_ExecuteButton("http://www.twitch.tv/warpportal", "http://www.twitch.tv/warpportal")
end
}
IroWikiButton = {
	x = 640,
	y = 330,
	w = 80,
	h = 80,
	ToolTipType = ToolTipStyle.TTS_BASIC,
	ToolTip = "Fish Patcher",
	SkinName = "FishPatcher\\Patcher\\fish_logo.bmp",
	Execute = function()
	C_ExecuteButton("https://irowiki.org/wiki/Main_Page", "https://irowiki.org/wiki/Main_Page")
end
}

-- Function #0
InitButtonInfos = function()
	AddButtonToTable(Ad1Button)
	AddButtonToTable(Ad2Button)
	AddButtonToTable(Ad3Button)
	AddButtonToTable(WebsiteButton)
	AddButtonToTable(ForumButton)
	AddButtonToTable(SupportButton)
	AddButtonToTable(IroWikiButton)
	AddButtonToTable(CloseButton)
	AddButtonToTable(FacebookButton)
	AddButtonToTable(TwitchButton)
end

-- Function #1
EnableGameStartButtons = function(bEnable)
	if StartButton.btnID ~= nil then
		C_EnableButton(StartButton.btnID, bEnable)
	end
	if ReplayButton.btnID ~= nil then
		C_EnableButton(ReplayButton.btnID, bEnable)
	end
	return
end

-- Function #2
InitTextInfos = function()
end
