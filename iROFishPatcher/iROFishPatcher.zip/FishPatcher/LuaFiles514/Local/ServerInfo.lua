g_patch_allow_name = "patch_allow.txt"
g_patch_list_name = "patch9.txt"
g_notice_open = "https://raw.githubusercontent.com/PinguDevRO/iROFishPatcherTool/main/notices/Ragnarok.html"
g_notice_close = "https://raw.githubusercontent.com/PinguDevRO/iROFishPatcherTool/main/notices/ServerCheck.html"
g_inf_file_name = "fishpatch.inf"
g_grf_file_name = "data.grf"
g_execute_file = "Updater.exe"
g_patch_up_name = "Patchup.exe"
g_execute_arg = "EasyAntiCheat.exe 1rag1"
g_execute_replay = "EasyAntiCheat.exe 1rag1 Replay"
g_execute_stream = "EasyAntiCheat.exe 1rag1 Steam"
g_use_protocol = 1
g_web_address = "raw.githubusercontent.com/PinguDevRO/iROFishPatcherTool/main/patch/patchlist"
g_http_address = "raw.githubusercontent.com/PinguDevRO/iROFishPatcherTool/main/patch"

InitServerInfo = function()
end
InitServerInfo()
