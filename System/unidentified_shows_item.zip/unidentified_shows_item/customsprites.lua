customsprites = {
    --[[
    ! YOU DO NOT HAVE TO RE-RUN iteminfo.bat AFTER EDITING THIS FILE !
    ! Sprites added here will take priority over original iteminfo !
	You can find sprite/resource names in iteminfo.lub or ratemyserver.net
	
	Format:
	[item ID] = "appearance sprite/resource name",
	--]]
	
	-- Misc
	[22511] = "�����ֹ���", -- Fenrir's Power Scroll -> Scroll sprite
	[4557]	= "ī�������", -- Weakened Fenrir Card -> Kafra Card sprite
	[6187]  = "�����ī��", -- Blank Card -> Spare Card sprite
}	