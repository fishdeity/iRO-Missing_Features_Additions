customeffects = {
    --[[
    ! YOU DO NOT HAVE TO RE-RUN iteminfo.bat AFTER EDITING THIS FILE !
    ! Effects added here will take priority over original iteminfo !

    Refer to effect_list.txt for an (incomplete) list of effect IDs
    1186: rare highlight (pink)
    1187: rare highlight (white)
    1188: rare highlight (blue)
    1189: rare highlight (gold)
    1190: rare highlight (purple)
    1191: rare highlight (orange)
    --]]

    --All entries must end with a comma (,)
    --[909] = {EffectID = 1189}, -- Jellopy, gold highlight
}